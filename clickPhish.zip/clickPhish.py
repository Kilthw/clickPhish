import pyautogui
pyautogui.PAUSE = 3
pyautogui.FAILSAFE = True

from time import sleep

def setupOutlook():
	#Waiting for Next button
	image = None
	while image == None:
		image = pyautogui.locateOnScreen('Back.png')
	pyautogui.click(pyautogui.center(image)[0]+75,pyautogui.center(image)[1])
	#waiting for Account Configuration
	image = None
	while image == None:
		image = pyautogui.locateOnScreen('AccountConfig.png')
	image = pyautogui.locateOnScreen('Back.png')
	pyautogui.click(pyautogui.center(image)[0]+75,pyautogui.center(image)[1])
	

#Inital Outlook Setup Wait
setupCheck = None
while setupCheck == None:
	setupCheck = pyautogui.locateOnScreen('outlookSetup.png')

#sleep(10)
pyautogui.click(pyautogui.center(setupCheck))
setupOutlook()
 
